# \# lotl is a data science library

# \# 

# \# from lotl import \*

# \#

# \# chain lotl(data).chain()

# \# flatten = lotl(data,nth=0,verbose=False).flatten()

# \# mean = lotl(data).mean()

