# lotl is a data science library

#

# from lotl import *

#

# chain = lotl(array).chain()

# flatten = lotl(array,nth=0).flatten()

# mean = lotl(array).mean()

# slope = lotl(array).slope()


