# lotl is a data science library

#

# from lotl import *

#

# chain (redundant itertools.chain) = lotl.chain(array)

# fill (fill a 1D or 2D array) = lotl.fill(int or array,nth=value)

# flatten (flatten multi-dimensional array) = lotl.flatten(array,nth=0)

# mean (redundant statistics.mean) = lotl.mean(array)

# nested total (counts how many layers deep at most an array is) = lotl.nested(array)

# slope (finds the slope average) = lotl.slope(array)
