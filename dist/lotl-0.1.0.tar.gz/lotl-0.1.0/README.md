# lotl is a dns lookup tool
# python3 -m lotl -host example.com
