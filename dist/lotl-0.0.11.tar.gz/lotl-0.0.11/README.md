# lotl is a data science library

#

# from lotl import *

#

# chain = lotl(array).chain()

# flatten = lotl(array,nth=0).flatten()

# mean = lotl(array).mean()

# outlier = lotl(array).outlier()

# slope = lotl(array).slope()


