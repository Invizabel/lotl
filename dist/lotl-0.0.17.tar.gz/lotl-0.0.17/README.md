# lotl is a data science library

#

# from lotl import *

#

# chain (redundant itertools.chain) = lotl(array).chain()

# flatten (flatten multi-dimensional array) = lotl(array,nth=0).flatten()

# mean (redundant statistics.mean) = lotl(array).mean()

# nested total (counts how many layers deep at most an array is) = lotl(array).nested()

# slope (finds the slope average) = lotl(array).slope()
