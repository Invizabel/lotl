# import lotl
# 
# if lotl("3DBenchy.stl").half(): # cuts model evenly in half (No guess work)
#   print("Done")
