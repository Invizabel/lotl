\# lotl is a data science library

\#

\# from lotl import \*

\#

\# chain = lotl(<list or tuple>).chain()

\# flatten = lotl(<list or tuple>,nth=0).flatten()

\# mean = lotl(<list or tuple>).mean()

